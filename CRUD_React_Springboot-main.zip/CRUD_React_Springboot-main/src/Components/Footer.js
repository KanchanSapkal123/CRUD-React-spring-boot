import React from 'react';

function Footer(props) {
    return (
        <div>
            <footer className='footer'>
                <span className='mt-5'>All Rights are reserved to Mr.Tukaram & Comp.</span>
            </footer>
        </div>
    );
}

export default Footer;